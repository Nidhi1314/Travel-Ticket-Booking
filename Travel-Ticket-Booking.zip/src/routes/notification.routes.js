import express from "express";
import {
    createNotification,
    getNotifications,
    markAsRead,
    deleteNotification,
} from "../controllers/notification.controller.js";
import { protect } from "../middleware/authMiddleware.js";

const router = express.Router();

router.route("/")
    .post(protect, createNotification) // Create a new notification
    .get(protect, getNotifications); // Get notifications for the logged-in user

router.route("/:id/read")
    .put(protect, markAsRead); // Mark a specific notification as read

router.route("/:id")
    .delete(protect, deleteNotification); // Delete a specific notification

export default router;
