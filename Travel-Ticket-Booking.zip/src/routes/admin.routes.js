import express from "express";
import {
    getAllUsers,
    getUserById,
    deleteUser,
    getAllPackages,
    getPackageById,
    deletePackage,
} from "../controllers/admin.controller.js";
import { protect, admin } from "../middleware/authMiddleware.js"; // Assuming you have an admin middleware

const router = express.Router();

router.route("/users").get(protect, admin, getAllUsers);
router.route("/users/:id").get(protect, admin, getUserById).delete(protect, admin, deleteUser);

router.route("/packages").get(protect, admin, getAllPackages);
router.route("/packages/:id").get(protect, admin, getPackageById).delete(protect, admin, deletePackage);

export default router;
